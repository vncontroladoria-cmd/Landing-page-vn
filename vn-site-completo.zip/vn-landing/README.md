# Site VN — Visão do Negócio

Landing page + Diagnóstico 360º.
Next.js 15 (App Router) · React 19 · TypeScript · Tailwind CSS v4 · Framer Motion.
Repositório GitHub: `vncontroladoria-cmd/Site` · Deploy automático na Vercel (projeto `Site`).

## Como editar

Todo o texto do site está em **`src/content/site.ts`**. Nenhum componente tem
texto fixo dentro. Para mudar qualquer coisa escrita, é só esse arquivo.

Edição pelo GitHub: abrir o arquivo → ícone de lápis → editar → Commit changes.
A Vercel republica sozinha em cerca de 1 minuto.

Regras para não quebrar: nunca apagar as aspas, nunca apagar a vírgula do fim
da linha, e usar aspas simples se precisar de aspas dentro do texto.

## Estrutura

```
src/
  app/
    globals.css          tokens do design system (bloco @theme)
    layout.tsx           fonte Inter, metadata, fundo ambiente
    page.tsx             ordem das seções da home
    diagnostico/page.tsx página do Diagnóstico 360º
  components/
    ambient-background.tsx   fundo em camadas + linhas de luz
    ui/                      button, spotlight-card, badge, reveal
    sections/
      site-nav · hero · steps · features · metodos · equipe
      pricing (eBooks) · faq · chamada-diagnostico · final-cta · site-footer
      quiz.tsx               motor do Diagnóstico 360º
  content/site.ts        TODO o conteúdo
public/img/              equipe-vn, nicollas-bueno, carol-calixto,
                         colecao-diagnostico, logo-vn
```

## Diagnóstico 360º

47 perguntas em 8 blocos, uma por tela, com barra de progresso.

| Bloco | Perguntas | Pontua |
|:---|:---|:---|
| Sobre o negócio (nome, telefone, empresa, perfil) | 8 | não |
| Controle financeiro | 7 | sim |
| Caixa e organização | 6 | sim |
| Clientes | 6 | sim |
| Serviços e faturamento | 6 | sim |
| Produtos e estoque | 5 | sim |
| Gestão e liderança | 5 | sim |
| Com suas palavras (abertas) | 4 | não |

Cada resposta vale 0, 1 ou 2 (`weight`). Cada bloco recebe nota de 0 a 100%,
classificada em Saudável / Atenção / Crítico. O bloco com a pior nota vira a
"Prioridade número 1" mostrada no resultado.

Atenção aos pesos invertidos: misturar PF/PJ, perder produto vencido e
"se considera profissional ou empresário" — neles a resposta boa é a que
parece negativa.

**Envio das respostas:** Web3Forms (sem banco de dados), para
`vncontroladoria@gmail.com`. A chave está em `diagnostico.accessKey`
no `site.ts`.

## Design

Estilo Linear/Modern adaptado: fundo quase preto com tom verde (`#040805`),
acento verde da marca (`#22C55E`), cartões de vidro com spotlight no mouse,
sombras em camadas, linhas de luz descendo pelo fundo, animações de 200–300ms
com easing expo-out. `prefers-reduced-motion` respeitado.

Tokens ficam no bloco `@theme` do `globals.css` — Tailwind v4 gera os
utilitários a partir dali (`--color-accent` vira `bg-accent`, `text-accent`).

## Contatos no site

WhatsApp (13) 98110-1850 · vncontroladoria@gmail.com ·
@vncontroladoriafinanceira · @nicollas.financeiro · @carol.calixtto
eBooks: https://pay.kiwify.com.br/VZdSts5

## Pendências

- Revisar as respostas do FAQ (foram escritas por IA, não validadas)
- Revisar a seção "Como a VN entra no seu negócio" (também não veio do site antigo)
- Logo em PNG com fundo transparente (hoje é JPG com fundo branco)
- Seção de palestras (sem material ainda)
- Limpar no repositório: pasta de nome longo em `src/components/sections` e
  `vn-landing.zip` na raiz
- Página de administração para editar o site sem GitHub (não iniciada)
